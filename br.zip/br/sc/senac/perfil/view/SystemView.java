package br.sc.senac.perfil.view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SystemView {
    package br.sc.senac.perfil.view.;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

    public class SystemView extends JFrame {

        JPanel pnlSystemView =  new JPanel();
        JMenuBar menuBar = new JMenuBar();
        public SystemView(){

            initComponents();
            initMenuBar();
            listener();
        }
        public void initComponents(){
            setTitle("Tela de sistema");
            setSize(1280,800);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setContentPane(pnlSystemView);
            setVisible(true);
            pnlSystemView.setLayout(null);
            setJMenuBar(menuBar);
        }
        public void initMenuBar() {
            JMenu cadastrosMenu = new JMenu("Cadastrar Pessoa");
            JMenu pesquisarMenu = new JMenu("Fazer o teste");
            JMenu sairMenu = new JMenu("Sair");

            JMenuItem clienteItem = new JMenuItem("Cliente");
            JMenuItem pesquisarItem = new JMenuItem("Pesquisar");
            JMenuItem sairItem = new JMenuItem("Sair");

            cadastrosMenu.add(clienteItem);
            pesquisarMenu.add(pesquisarItem);
            sairMenu.add(sairItem);


            menuBar.add(cadastrosMenu);
            menuBar.add(pesquisarMenu);
            menuBar.add(sairMenu);

            clienteItem.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    new ClientView();
                    dispose();
                }
            });


        }
